


// Variables de URL utilizadas en los ejemplos
const fsaURL =
  "https://gb-advisorspresales.myfreshworks.com/crm/sales/api/contacts/filters";

const fsaProducts =
  "https://gb-advisorspresales.myfreshworks.com/crm/sales/api/cpq/products?include=product_pricings";
// const fsCategoryURL =
//   "https://gb-advisorspresales.freshservice.com/api/v2/service_catalog/items/";

// Variables de credenciales utilizadas en los ejemplos

const fsaAuthToken = "Token token=q_hQT4c5f8EbXufny2jvSw";
const fsaAPIKEY =
  "Basic ZXJpeC5ndXRpZXJyZXpAZ2ItYWR2aXNvcnMuY29tOkFkbWluNDYwLg==";

