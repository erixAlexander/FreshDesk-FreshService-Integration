const getTargetButton = document.getElementById("get-targets")
const dropDownModule = document.querySelector(".module-dropdown")
const dropDownProducts = document.querySelector(".products")
const divProducts = document.querySelector(".select-prod-div")
const dropDownPrices = document.querySelector(".prices")
const divPrices = document.querySelector(".price-div")
const createDealButton = document.querySelector(".button-fsa")



const  getTicketDetails = async function(){
  const getCurrentTicket = await client.data.get("ticket")
  const getCurrentContact = await client.data.get("contact")
  //console.log(getCurrentTicket)
  //console.log(getCurrentContact)
  const currentTicket = {
    subject : getCurrentTicket.ticket.subject,
    ticketId : getCurrentTicket.ticket.id,
    name: getCurrentContact.contact.name, 
    email: getCurrentContact.contact.email
    
  }
  return currentTicket
  //const currentTicket = await getTicketDetails().then(function(data) {console.log(data)})
}
  

dropDownModule.addEventListener('change', async function(e) {

  e.preventDefault();
  e.stopPropagation();
  try {
    if (dropDownModule.value === "products"){
    const apiCall = await client.request.get(fsaProducts, {
      headers: {
        "Content-Type": "application/json",
        "Authorization": fsaAPIKEY
      }
    })
    
      const dataObj = JSON.parse(apiCall.response)
      //console.log(dataObj.products)
      const productList = dataObj.products
      dropDownProducts.innerHTML = '<option value="select-product">Select a Product</option>'
      productList.forEach(product => {
        dropDownProducts.innerHTML += `<option value="${product.id}">${product.name}</option>`
      });
      divProducts.classList.remove("el-none")
    }else if (dropDownModule.value === "select-module"){
      dropDownProducts.innerHTML = ""
      divPrices.innerHTML= ""
      divProducts.classList.add("el-none")
      divPrices.classList.add("el-none") 
    }
  } catch (error) {
    console.log(error)
  }  
})

dropDownProducts.addEventListener('change', async function(e) {
  
  e.preventDefault();
  e.stopPropagation();
  try {
    const productID = dropDownProducts.value
    //console.log(productID)
    if (dropDownModule.value !== "select-module" && dropDownProducts.value !== "select-product"){
    const fsaProduct = `https://gb-advisorspresales.myfreshworks.com/crm/sales/api/cpq/products/${productID}?include=product_pricings`
    const apiCall = await client.request.get(fsaProduct, {
      headers: {
        "Content-Type": "application/json",
        "Authorization": fsaAPIKEY
      }
    })
    
      const dataObj = JSON.parse(apiCall.response)
      //console.log(dataObj.product.custom_field.cf_precio_producto)
      const price = dataObj.product.custom_field.cf_precio_producto
      //console.log(price)
      divPrices.innerHTML = `<p><span class= "title" >Price is:</span> ${price}$</p>`
      divPrices.classList.remove("el-none")
      createDealButton.classList.remove("el-none")
  } else if (dropDownModule.value === "select-module" || dropDownProducts.value === "select-product" ){
      divPrices.classList.add("el-none")      
    }
  } catch (error) {
    console.log(error)
  }  
})

// ticketCreateButton.addEventListener("click", async function(e){
//   e.preventDefault();
//   e.stopPropagation();
//   const currentTicket = await getTicketDetails().then(async function(data){
//       const itemID = dropDownItems.options[dropDownItems.selectedIndex].getAttribute("data-displayId")
 
//       await client.request.post(`https://gb-advisorspresales.freshservice.com/api/v2/service_catalog/items/${itemID}/place_request`, 
//       { headers: {
//           "Content-Type": "application/json",
//           "Authorization": freshBasicAuth
//         }, 
//         body: JSON.stringify({
//             email: data.email,
//             quantity: 1
//         })
//       }).then (
//         async function(data) {
//           console.log(data);
//           ticketBody = JSON.parse(data.response).service_request
//           console.log(ticketBody);
//           ticketCreated.innerHTML = `<p><span class= "ticket-title" >Title:</span> ${ticketBody.subject}</p>
//           <p><span class= "ticket-title" >Ticket ID:</span> ${ticketBody.id}</p>`

//           await fetch("http://localhost:3000/test", {
//             method: 'POST', // or 'PUT'
//             body: JSON.stringify({test1 :"1", test2 : "2"}), // data can be `string` or {object}!
//             headers:{
//               'Content-Type': 'application/json'
//             }
//           }).then(res => {
//             return res.json()
//           }).then(res2 => console.log(res2))
//           .catch(error => console.error('Error:', error));
//         },
//         function(error) {
//           console.log(error);
//         });
//       })
//     })

